# 🛡️ Super Admin Module - Complete Implementation Guide

> **Version:** 1.0  
> **Created:** December 24, 2025  
> **Status:** ✅ Implementation Complete

---

## 📋 Table of Contents

1. [Overview](#overview)
2. [User Roles](#user-roles)
3. [Module Features](#module-features)
4. [Dashboard](#1-super-admin-dashboard)
5. [Category Management](#2-category-management)
6. [Approval Flow Configuration](#3-approval-flow-configuration)
7. [User Management](#4-user-management)
8. [Approver Overview](#5-approver-overview)
9. [Complete Ticket Flow](#6-complete-ticket-approval-flow)
10. [Data Models](#7-data-models)
11. [API Endpoints](#8-api-endpoints)
12. [File Structure](#9-file-structure)
13. [Permission Matrix](#10-permission-matrix)
14. [Implementation Phases](#11-implementation-phases)

---

## Overview

The Super Admin module provides centralized control over the RMG Portal system, including:
- User management with role assignment
- Category configuration with customizable approval workflows
- Approver assignment at category level (L1, L2, L3)
- System monitoring and configuration

### Key Concept: Category-Specific Approval Flow

Unlike traditional role-based approval where ALL users with L1_APPROVER role see ALL tickets, this system allows:
- **Category-specific approvers**: Only designated approvers for a category see those tickets
- **Flexible approval levels**: Enable/disable L1, L2, L3 per category
- **Multiple approvers per level**: Any one can approve (no bottleneck)

---

## User Roles

### Existing Roles
| Role | Description |
|------|-------------|
| `EMPLOYEE` | Regular employee with basic access |
| `MANAGER` | Team manager with leave approvals |
| `HR` | HR management |
| `RMG` | Resource Management Group |
| `IT_ADMIN` | IT ticket management |
| `IT_EMPLOYEE` | IT support staff |
| `L1_APPROVER` | Level 1 helpdesk approver (legacy) |
| `L2_APPROVER` | Level 2 helpdesk approver (legacy) |
| `L3_APPROVER` | Level 3 helpdesk approver (legacy) |

### New Role
| Role | Description |
|------|-------------|
| `SUPER_ADMIN` | Full system access, can configure everything |

---

## Module Features

| Feature | Description |
|---------|-------------|
| **Dashboard** | System overview, stats, quick actions |
| **Category Management** | CRUD categories with approval config |
| **Approval Flow Config** | Configure L1/L2/L3 per category |
| **Approver Assignment** | Assign specific employees as approvers |
| **User Management** | Manage users, roles, status |
| **Approver Overview** | View all approvers across categories |
| **System Configuration** | Departments, queues, settings |

---

## 1. Super Admin Dashboard

### Layout
```
┌─────────────────────────────────────────────────────────────────────────────────┐
│  🛡️ SUPER ADMIN DASHBOARD                                     [Sai Nikhil] 👤  │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  ┌───────────────┐ ┌───────────────┐ ┌───────────────┐ ┌───────────────┐       │
│  │ 👥 Total Users│ │ 🎫 Open Tickets│ │ ⏳ Pending    │ │ 📂 Categories │       │
│  │     156       │ │      23       │ │   Approvals   │ │      18       │       │
│  │ +5 this week  │ │ 8 critical    │ │      12       │ │ 3 IT, 2 Fac.  │       │
│  └───────────────┘ └───────────────┘ └───────────────┘ └───────────────┘       │
│                                                                                 │
│  ┌─────────────────────────────────┐  ┌─────────────────────────────────┐      │
│  │ 🔄 QUICK ACTIONS                │  │ 📈 SYSTEM HEALTH                │      │
│  │                                 │  │                                 │      │
│  │ [👤 Manage Users]               │  │ Database: ✅ Connected          │      │
│  │ [📂 Manage Categories]          │  │ API: ✅ Running                 │      │
│  │ [✅ Manage Approvers]           │  │ Last Backup: 2 hours ago        │      │
│  │ [⚙️ System Configuration]       │  │ Active Sessions: 45             │      │
│  └─────────────────────────────────┘  └─────────────────────────────────┘      │
│                                                                                 │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │ 📊 APPROVAL PIPELINE OVERVIEW                                           │   │
│  │                                                                          │   │
│  │   L1 Pending: 5 tickets    L2 Pending: 3 tickets    L3 Pending: 1 ticket│   │
│  │   ████████░░░░ (8)         █████░░░░░░░ (5)         ██░░░░░░░░░░ (2)    │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### Stats Cards
- Total Users (with weekly change)
- Open Tickets (with critical count)
- Pending Approvals (across all levels)
- Categories (grouped by type)

### Quick Actions
- Navigate to User Management
- Navigate to Category Management
- Navigate to Approver Overview
- Navigate to System Configuration

### Approval Pipeline
- Visual representation of tickets at each approval level
- Click to drill down into specific level

---

## 2. Category Management

### Category List View
```
┌─────────────────────────────────────────────────────────────────────────────────┐
│  📂 CATEGORY MANAGEMENT                              [+ Add New Category]       │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  Filter: [All Categories ▼]  [IT ▼]  🔍 Search...                              │
│                                                                                 │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │ CATEGORY          │ SUB-CATEGORY      │ APPROVAL FLOW    │ STATUS │ ACT │   │
│  ├───────────────────┼───────────────────┼──────────────────┼────────┼─────┤   │
│  │ 💻 IT             │ New Laptop        │ L1 → L2 → L3     │ Active │ ✏️🗑️│   │
│  │ 💻 IT             │ Software Install  │ L1 → L2          │ Active │ ✏️🗑️│   │
│  │ 💻 IT             │ Password Reset    │ No Approval      │ Active │ ✏️🗑️│   │
│  │ 💻 IT             │ VPN Access        │ L1 only          │ Active │ ✏️🗑️│   │
│  │ 🏢 Facilities     │ Parking Pass      │ L1 → L2          │ Active │ ✏️🗑️│   │
│  │ 🏢 Facilities     │ Access Card       │ L1 only          │ Active │ ✏️🗑️│   │
│  │ 💰 Finance        │ Expense Claim     │ L1 → L2 → L3     │ Active │ ✏️🗑️│   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### Category Fields
| Field | Type | Required | Description |
|-------|------|----------|-------------|
| highLevelCategory | Enum | Yes | IT, Facilities, Finance |
| subCategory | String | Yes | Category name |
| requiresApproval | Boolean | Yes | Enable/disable approval |
| processingQueue | String | Yes | Target team |
| specialistQueue | String | Yes | Specialist assignment |
| order | Number | No | Display order |
| isActive | Boolean | Yes | Active/Inactive status |
| approvalConfig | Object | No | L1/L2/L3 configuration |

---

## 3. Approval Flow Configuration

### Add/Edit Category Form with Approval Config
```
┌─────────────────────────────────────────────────────────────────────────────────┐
│  ➕ ADD NEW CATEGORY                                                    [✕]    │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │ 📋 BASIC INFORMATION                                                    │   │
│  │                                                                          │   │
│  │ High Level Category *    Sub-Category Name *                             │   │
│  │ ┌─────────────────────┐  ┌───────────────────────────────────────────┐  │   │
│  │ │ IT                ▼ │  │ New Laptop Request                        │  │   │
│  │ └─────────────────────┘  └───────────────────────────────────────────┘  │   │
│  │                                                                          │   │
│  │ Processing Queue *       Specialist Queue *                              │   │
│  │ ┌─────────────────────┐  ┌───────────────────────────────────────────┐  │   │
│  │ │ IT Support        ▼ │  │ Hardware Team                           ▼ │  │   │
│  │ └─────────────────────┘  └───────────────────────────────────────────┘  │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
│                                                                                 │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │ ⚙️ APPROVAL WORKFLOW CONFIGURATION                                      │   │
│  │                                                                          │   │
│  │  ☑️ This category requires approval before processing                   │   │
│  │                                                                          │   │
│  │  ╔════════════════════════════════════════════════════════════════════╗ │   │
│  │  ║ 🔵 LEVEL 1 APPROVAL - Team Lead                                    ║ │   │
│  │  ║ ☑️ Enable Level 1                                                   ║ │   │
│  │  ║ Approvers: [🔍 Search employees...]                                ║ │   │
│  │  ║ Selected: [👤 Rajesh K. ✕] [👤 Priya S. ✕] [👤 John D. ✕]         ║ │   │
│  │  ╚════════════════════════════════════════════════════════════════════╝ │   │
│  │                              ↓                                           │   │
│  │  ╔════════════════════════════════════════════════════════════════════╗ │   │
│  │  ║ 🟡 LEVEL 2 APPROVAL - Manager                                      ║ │   │
│  │  ║ ☑️ Enable Level 2                                                   ║ │   │
│  │  ║ Approvers: [🔍 Search employees...]                                ║ │   │
│  │  ║ Selected: [👤 Amit P. ✕] [👤 Sarah W. ✕]                           ║ │   │
│  │  ╚════════════════════════════════════════════════════════════════════╝ │   │
│  │                              ↓                                           │   │
│  │  ╔════════════════════════════════════════════════════════════════════╗ │   │
│  │  ║ 🔴 LEVEL 3 APPROVAL - Director (Final)                             ║ │   │
│  │  ║ ☐ Enable Level 3 (Optional)                                        ║ │   │
│  │  ║ ⚠️ Level 3 is disabled. Enable to add approvers.                   ║ │   │
│  │  ╚════════════════════════════════════════════════════════════════════╝ │   │
│  │                                                                          │   │
│  │  📝 APPROVAL FLOW PREVIEW:                                              │   │
│  │  Employee → [L1: Rajesh/Priya/John] → [L2: Amit/Sarah] → IT Team       │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
│                                                                                 │
│                                              [Cancel]    [💾 Save Category]     │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### Approval Configuration Rules
1. **requiresApproval = false**: Ticket goes directly to processing queue
2. **L1 disabled**: Skip L1, go to L2 (if enabled)
3. **L2 disabled**: Skip L2, go to L3 (if enabled)
4. **L3 disabled**: After previous approvals, route to processing
5. **Multiple approvers**: ANY ONE approver can approve/reject
6. **Empty approvers list**: If level enabled but no approvers, show warning

---

## 4. User Management

### User List View
```
┌─────────────────────────────────────────────────────────────────────────────────┐
│  👥 USER MANAGEMENT                                         [+ Add New User]    │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  Filter: [All Roles ▼]  [All Departments ▼]  [Active ▼]  🔍 Search...          │
│                                                                                 │
│  ┌─────────────────────────────────────────────────────────────────────────┐   │
│  │ USER              │ EMAIL              │ ROLE        │ DEPT    │ STATUS │   │
│  ├───────────────────┼────────────────────┼─────────────┼─────────┼────────┤   │
│  │ 👤 Sai Nikhil     │ sai@company.com    │ SUPER_ADMIN │ IT      │ Active │   │
│  │ 👤 Rajesh Kumar   │ rajesh@company.com │ MANAGER     │ IT      │ Active │   │
│  │ 👤 Priya Sharma   │ priya@company.com  │ HR          │ HR      │ Active │   │
│  │ 👤 John Doe       │ john@company.com   │ EMPLOYEE    │ Dev     │ Active │   │
│  │ 👤 Sarah Wilson   │ sarah@company.com  │ IT_ADMIN    │ IT      │ Active │   │
│  └─────────────────────────────────────────────────────────────────────────┘   │
│                                                                                 │
│  ROLE LEGEND:                                                                   │
│  🟢 EMPLOYEE  🔵 MANAGER  🟣 HR  🟠 IT_ADMIN  🔴 SUPER_ADMIN  🟤 RMG           │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### User Edit Modal
```
┌─────────────────────────────────────────────────────────────────────────────┐
│  ✏️ EDIT USER: Rajesh Kumar                                           [✕]  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│  Name *                          Email *                                    │
│  [Rajesh Kumar              ]    [rajesh@company.com                   ]   │
│                                                                             │
│  Employee ID                     Department                                 │
│  [EMP001                    ]    [Information Technology            ▼  ]   │
│                                                                             │
│  Primary Role *                  Status                                     │
│  [MANAGER                  ▼]    [✅ Active                         ▼  ]   │
│                                                                             │
│  ┌───────────────────────────────────────────────────────────────────────┐ │
│  │ 📋 CATEGORY APPROVER ASSIGNMENTS                                      │ │
│  │                                                                        │ │
│  │ This user is assigned as approver for:                                │ │
│  │                                                                        │ │
│  │ │ Category               │ Level  │ Status                       │    │ │
│  │ ├────────────────────────┼────────┼──────────────────────────────┤    │ │
│  │ │ IT > New Laptop        │ L1     │ ✅ Active                    │    │ │
│  │ │ IT > Software Install  │ L1     │ ✅ Active                    │    │ │
│  │ │ Facilities > Parking   │ L2     │ ✅ Active                    │    │ │
│  │                                                                        │ │
│  │ ⚠️ Changing role/status will affect approver assignments              │ │
│  └───────────────────────────────────────────────────────────────────────┘ │
│                                                                             │
│                                       [Cancel]    [💾 Save Changes]         │
└─────────────────────────────────────────────────────────────────────────────┘
```

### User Actions
- Create new user
- Edit user details
- Change user role
- Activate/Deactivate user
- View approver assignments
- Reset password

---

## 5. Approver Overview

### Approver Dashboard
```
┌─────────────────────────────────────────────────────────────────────────────────┐
│  ✅ APPROVER OVERVIEW                                                           │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│  ┌───────────────────────────────────────────────────────────────────────────┐ │
│  │ 📊 APPROVAL STATISTICS                                                     │ │
│  │ ┌─────────────────┐ ┌─────────────────┐ ┌─────────────────┐              │ │
│  │ │ 🔵 L1 Pending   │ │ 🟡 L2 Pending   │ │ 🔴 L3 Pending   │              │ │
│  │ │       5        │ │       3        │ │       1        │              │ │
│  │ │ Avg: 2.5 hrs   │ │ Avg: 4.1 hrs   │ │ Avg: 8.2 hrs   │              │ │
│  │ └─────────────────┘ └─────────────────┘ └─────────────────┘              │ │
│  └───────────────────────────────────────────────────────────────────────────┘ │
│                                                                                 │
│  ┌───────────────────────────────────────────────────────────────────────────┐ │
│  │ 📋 APPROVERS BY CATEGORY                                                   │ │
│  │                                                                            │ │
│  │ ┌──────────────────────────────────────────────────────────────────────┐  │ │
│  │ │ 💻 IT > New Laptop Request                          [Edit Approvers] │  │ │
│  │ ├──────────────────────────────────────────────────────────────────────┤  │ │
│  │ │ L1: 👤 Rajesh Kumar, 👤 Priya Sharma, 👤 John Doe    (3 approvers)  │  │ │
│  │ │ L2: 👤 Amit Patel, 👤 Sarah Wilson                   (2 approvers)  │  │ │
│  │ │ L3: ⚪ Not Configured                                               │  │ │
│  │ │ Pending: 2 at L1, 1 at L2                                           │  │ │
│  │ └──────────────────────────────────────────────────────────────────────┘  │ │
│  │                                                                            │ │
│  │ ┌──────────────────────────────────────────────────────────────────────┐  │ │
│  │ │ 💰 Finance > Expense Claim                          [Edit Approvers] │  │ │
│  │ ├──────────────────────────────────────────────────────────────────────┤  │ │
│  │ │ L1: 👤 Team Lead Pool                                (4 approvers)  │  │ │
│  │ │ L2: 👤 Finance Manager Pool                          (2 approvers)  │  │ │
│  │ │ L3: 👤 CFO                                           (1 approver)   │  │ │
│  │ │ Pending: 3 at L1, 2 at L2, 1 at L3                                  │  │ │
│  │ └──────────────────────────────────────────────────────────────────────┘  │ │
│  └───────────────────────────────────────────────────────────────────────────┘ │
│                                                                                 │
│  ┌───────────────────────────────────────────────────────────────────────────┐ │
│  │ 👥 ALL APPROVERS LIST                                                      │ │
│  │                                                                            │ │
│  │ │ APPROVER         │ AS L1 FOR           │ AS L2 FOR      │ AS L3 FOR   │ │
│  │ ├──────────────────┼─────────────────────┼────────────────┼─────────────┤ │
│  │ │ 👤 Rajesh Kumar   │ Laptop, Software    │ -              │ -           │ │
│  │ │ 👤 Amit Patel     │ -                   │ Laptop, SW     │ -           │ │
│  │ │ 👤 Sarah Wilson   │ -                   │ Laptop         │ Expense     │ │
│  └───────────────────────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

## 6. Complete Ticket Approval Flow

### Flow Diagram
```
EMPLOYEE RAISES TICKET
        │
        ▼
┌─────────────────┐
│ System checks   │
│ category config │
└────────┬────────┘
         │
         ├─── requiresApproval = FALSE ───────────────────┐
         │                                                 │
         │                                                 ▼
         │                                    ┌─────────────────────┐
         │                                    │ Route directly to   │
         │                                    │ IT Team / Specialist│
         │                                    └─────────────────────┘
         │
         ├─── requiresApproval = TRUE
         │
         ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                                                                          │
│   ┌─────────────────────────────────────────────────────────────────┐   │
│   │ 🔵 LEVEL 1 APPROVAL                                             │   │
│   │                                                                  │   │
│   │ IF l1.enabled = TRUE:                                           │   │
│   │   - Notify ONLY L1 approvers assigned to THIS category          │   │
│   │   - ANY ONE approver can approve/reject                         │   │
│   │   - Status: "Pending L1 Approval"                               │   │
│   │                                                                  │   │
│   │   APPROVED → Check if L2 enabled                                │   │
│   │   REJECTED → Ticket Rejected, Notify Employee, Flow Ends ❌      │   │
│   └──────────────────────────────────────────────────────────────────┘   │
│                              │                                           │
│                              ▼                                           │
│   ┌─────────────────────────────────────────────────────────────────┐   │
│   │ 🟡 LEVEL 2 APPROVAL                                             │   │
│   │                                                                  │   │
│   │ IF l2.enabled = TRUE:                                           │   │
│   │   - Notify ONLY L2 approvers assigned to THIS category          │   │
│   │   - ANY ONE approver can approve/reject                         │   │
│   │   - Status: "Pending L2 Approval"                               │   │
│   │                                                                  │   │
│   │   APPROVED → Check if L3 enabled                                │   │
│   │   REJECTED → Ticket Rejected, Notify Employee, Flow Ends ❌      │   │
│   └──────────────────────────────────────────────────────────────────┘   │
│                              │                                           │
│                              ▼                                           │
│   ┌─────────────────────────────────────────────────────────────────┐   │
│   │ 🔴 LEVEL 3 APPROVAL (FINAL)                                     │   │
│   │                                                                  │   │
│   │ IF l3.enabled = TRUE:                                           │   │
│   │   - Notify ONLY L3 approvers assigned to THIS category          │   │
│   │   - ANY ONE approver can approve/reject                         │   │
│   │   - Status: "Pending L3 Approval"                               │   │
│   │                                                                  │   │
│   │   APPROVED → Continue to processing                             │   │
│   │   REJECTED → Ticket Rejected, Notify Employee, Flow Ends ❌      │   │
│   └──────────────────────────────────────────────────────────────────┘   │
│                              │                                           │
└──────────────────────────────┼───────────────────────────────────────────┘
                               │
                               ▼
┌─────────────────────────────────────────────────────────────────────────┐
│ ✅ ALL APPROVALS COMPLETE                                               │
│                                                                          │
│ - Status: "Approved - Routed to Processing"                             │
│ - Assign to IT Specialist based on specialistQueue                      │
│ - Notify Employee: "Your request has been approved"                     │
│ - Notify IT Team: "New ticket assigned"                                 │
│                                                                          │
│ Flow continues to IT Team processing...                                 │
└─────────────────────────────────────────────────────────────────────────┘
```

### Flow Examples

| Category | Approval Flow | Explanation |
|----------|---------------|-------------|
| New Laptop | L1 → L2 → L3 → IT | Full 3-level approval |
| Software Install | L1 → L2 → IT | 2-level, no director approval |
| Password Reset | → IT | No approval needed |
| VPN Access | L1 → IT | Single level approval |
| Expense Claim | L1 → L2 → L3 → Finance | Full approval for finance |

---

## 7. Data Models

### Enhanced SubCategoryConfig Schema

```typescript
// server/src/models/SubCategoryConfig.ts

interface ApproverInfo {
  employeeId: string;
  name: string;
  email: string;
  designation?: string;
}

interface ApprovalLevelConfig {
  enabled: boolean;
  approvers: ApproverInfo[];
}

interface ApprovalConfig {
  l1: ApprovalLevelConfig;
  l2: ApprovalLevelConfig;
  l3: ApprovalLevelConfig;
}

interface SubCategoryConfig {
  _id: ObjectId;
  highLevelCategory: 'IT' | 'Facilities' | 'Finance';
  subCategory: string;
  requiresApproval: boolean;
  processingQueue: string;
  specialistQueue: string;
  order: number;
  isActive: boolean;
  
  // NEW: Approval Flow Configuration
  approvalConfig: ApprovalConfig;
  
  createdAt: Date;
  updatedAt: Date;
}
```

### Example Document

```json
{
  "_id": "ObjectId('...')",
  "highLevelCategory": "IT",
  "subCategory": "New Laptop Request",
  "requiresApproval": true,
  "processingQueue": "IT Support",
  "specialistQueue": "Hardware Team",
  "order": 1,
  "isActive": true,
  "approvalConfig": {
    "l1": {
      "enabled": true,
      "approvers": [
        {
          "employeeId": "EMP001",
          "name": "Rajesh Kumar",
          "email": "rajesh@company.com",
          "designation": "Team Lead"
        },
        {
          "employeeId": "EMP002",
          "name": "Priya Sharma",
          "email": "priya@company.com",
          "designation": "Team Lead"
        }
      ]
    },
    "l2": {
      "enabled": true,
      "approvers": [
        {
          "employeeId": "MGR001",
          "name": "Amit Patel",
          "email": "amit@company.com",
          "designation": "IT Manager"
        }
      ]
    },
    "l3": {
      "enabled": false,
      "approvers": []
    }
  },
  "createdAt": "2025-12-24T10:00:00Z",
  "updatedAt": "2025-12-24T10:00:00Z"
}
```

### User Model Update

```typescript
// server/src/models/User.ts

// Add SUPER_ADMIN to role enum
role: {
  type: String,
  required: true,
  enum: [
    'EMPLOYEE',
    'HR',
    'RMG',
    'MANAGER',
    'IT_ADMIN',
    'IT_EMPLOYEE',
    'L1_APPROVER',   // Legacy - kept for backward compatibility
    'L2_APPROVER',   // Legacy - kept for backward compatibility
    'L3_APPROVER',   // Legacy - kept for backward compatibility
    'SUPER_ADMIN'    // NEW
  ]
}
```

---

## 8. API Endpoints

### Super Admin Routes

```
BASE: /api/superadmin

DASHBOARD
─────────────────────────────────────────────────────────
GET    /dashboard/stats          # Get dashboard statistics
GET    /dashboard/health         # Get system health status

CATEGORY MANAGEMENT
─────────────────────────────────────────────────────────
GET    /categories               # List all categories
POST   /categories               # Create new category
GET    /categories/:id           # Get category by ID
PUT    /categories/:id           # Update category
DELETE /categories/:id           # Delete category

APPROVER MANAGEMENT
─────────────────────────────────────────────────────────
GET    /approvers                # List all approvers (grouped)
GET    /approvers/stats          # Approver statistics
PUT    /categories/:id/approvers # Update category approvers

USER MANAGEMENT
─────────────────────────────────────────────────────────
GET    /users                    # List all users (paginated)
POST   /users                    # Create new user
GET    /users/:id                # Get user by ID
PUT    /users/:id                # Update user
PUT    /users/:id/status         # Activate/Deactivate user
PUT    /users/:id/role           # Change user role
DELETE /users/:id                # Delete user

SEARCH
─────────────────────────────────────────────────────────
GET    /employees/search?q=      # Search employees for picker
```

### Request/Response Examples

#### Create Category with Approval Config
```http
POST /api/superadmin/categories
Content-Type: application/json

{
  "highLevelCategory": "IT",
  "subCategory": "New Laptop Request",
  "requiresApproval": true,
  "processingQueue": "IT Support",
  "specialistQueue": "Hardware Team",
  "order": 1,
  "isActive": true,
  "approvalConfig": {
    "l1": {
      "enabled": true,
      "approvers": [
        { "employeeId": "EMP001", "name": "Rajesh Kumar", "email": "rajesh@company.com" }
      ]
    },
    "l2": {
      "enabled": true,
      "approvers": [
        { "employeeId": "MGR001", "name": "Amit Patel", "email": "amit@company.com" }
      ]
    },
    "l3": {
      "enabled": false,
      "approvers": []
    }
  }
}
```

#### Response
```json
{
  "success": true,
  "data": {
    "_id": "...",
    "highLevelCategory": "IT",
    "subCategory": "New Laptop Request",
    ...
  }
}
```

---

## 9. File Structure

```
src/
├── pages/
│   └── superadmin/
│       ├── SuperAdminDashboard.tsx      # Main dashboard
│       ├── CategoryManagement.tsx        # Category CRUD
│       ├── ApproverOverview.tsx          # Approver list & stats
│       ├── UserManagement.tsx            # User CRUD
│       └── SystemConfiguration.tsx       # Other settings
│
├── components/
│   └── superadmin/
│       ├── CategoryForm.tsx              # Add/Edit category
│       ├── CategoryTable.tsx             # Category list table
│       ├── ApprovalFlowConfig.tsx        # L1/L2/L3 config UI
│       ├── ApprovalFlowPreview.tsx       # Visual flow preview
│       ├── ApproverPicker.tsx            # Employee multi-select
│       ├── ApproverCard.tsx              # Category approver card
│       ├── UserTable.tsx                 # Users data table
│       ├── UserEditModal.tsx             # Edit user modal
│       ├── UserCreateModal.tsx           # Create user modal
│       ├── StatsCard.tsx                 # Dashboard stat card
│       └── SystemHealthCard.tsx          # System health display
│
├── store/
│   └── superAdminStore.ts                # Zustand store
│
├── services/
│   └── superAdminService.ts              # API service
│
└── types/
    └── superAdmin.ts                     # TypeScript types

server/
├── routes/
│   └── superAdmin.ts                     # All super admin routes
│
├── controllers/
│   └── superAdminController.ts           # Route handlers
│
├── models/
│   └── SubCategoryConfig.ts              # Updated schema
│
├── middleware/
│   └── superAdminAuth.ts                 # Auth middleware
│
└── services/
    └── superAdminService.ts              # Business logic
```

---

## 10. Permission Matrix

| Feature | SUPER_ADMIN | HR | IT_ADMIN | MANAGER | EMPLOYEE |
|---------|:-----------:|:--:|:--------:|:-------:|:--------:|
| View Super Admin Dashboard | ✅ | ❌ | ❌ | ❌ | ❌ |
| Manage Categories | ✅ | ❌ | ❌ | ❌ | ❌ |
| Configure Approval Flow | ✅ | ❌ | ❌ | ❌ | ❌ |
| Assign Approvers | ✅ | ❌ | ❌ | ❌ | ❌ |
| View All Users | ✅ | ✅ | ❌ | ❌ | ❌ |
| Edit User Roles | ✅ | ❌ | ❌ | ❌ | ❌ |
| Deactivate Users | ✅ | ✅ | ❌ | ❌ | ❌ |
| Create Users | ✅ | ✅ | ❌ | ❌ | ❌ |
| Delete Users | ✅ | ❌ | ❌ | ❌ | ❌ |
| View Audit Logs | ✅ | ❌ | ❌ | ❌ | ❌ |
| System Configuration | ✅ | ❌ | ❌ | ❌ | ❌ |

---

## 11. Implementation Phases

### Phase 1: Foundation (Week 1)
- [ ] Add `SUPER_ADMIN` role to User model
- [ ] Update types and role permissions
- [ ] Create Super Admin routes with auth middleware
- [ ] Create basic Super Admin Dashboard

### Phase 2: Category Management (Week 2)
- [ ] Update SubCategoryConfig schema with approvalConfig
- [ ] Create Category Management page
- [ ] Build ApprovalFlowConfig component
- [ ] Implement ApproverPicker with employee search
- [ ] Create/Update category API endpoints

### Phase 3: User Management (Week 3)
- [ ] Create User Management page
- [ ] Build User table with filters
- [ ] Implement User create/edit modals
- [ ] Add role change functionality
- [ ] Show approver assignments on user

### Phase 4: Approver Overview (Week 3)
- [ ] Create Approver Overview page
- [ ] Build category-wise approver view
- [ ] Add approval statistics
- [ ] Implement quick edit approvers

### Phase 5: Integration (Week 4)
- [ ] Update helpdesk ticket creation to use new flow
- [ ] Modify approval notification logic
- [ ] Update approver page to filter by category
- [ ] Testing and bug fixes

---

## 12. Navigation

### Sidebar Menu for Super Admin
```
┌────────────────────────┐
│  🛡️ SUPER ADMIN       │
├────────────────────────┤
│  📊 Dashboard          │
│  📂 Categories         │
│  ✅ Approvers          │
│  👥 Users              │
│  ⚙️ Configuration      │
│  ────────────────────  │
│  📋 Audit Logs         │
│  📈 Reports            │
└────────────────────────┘
```

### Route Configuration
```typescript
// Add to roleConfig.ts

SUPER_ADMIN: [
  '/dashboard',
  '/superadmin/dashboard',
  '/superadmin/categories',
  '/superadmin/approvers',
  '/superadmin/users',
  '/superadmin/configuration',
  '/profile',
  // ... all other routes (full access)
]
```

---

## 13. Key Benefits

| Benefit | Description |
|---------|-------------|
| **Granular Control** | Specific approvers per category |
| **Flexible Workflows** | Enable/disable levels as needed |
| **No Bottlenecks** | Multiple approvers, any can act |
| **Clear Visibility** | See who approves what |
| **Easy Management** | Super Admin controls everything |
| **Scalable** | Add new categories easily |

---

## 14. Future Enhancements

- **Audit Logs**: Track all super admin actions
- **Email Notifications**: Configure notification templates
- **SLA Configuration**: Set approval time limits per category
- **Delegation**: Allow approvers to delegate temporarily
- **Bulk Operations**: Bulk assign/remove approvers
- **Reports**: Approval time analytics, bottleneck identification

---

> **Next Steps**: Proceed with Phase 1 implementation
