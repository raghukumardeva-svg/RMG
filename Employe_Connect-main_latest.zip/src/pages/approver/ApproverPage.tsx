import { ApproverDashboard } from '@/components/helpdesk/ApproverDashboard';

export default function ApproverPage() {
  return <ApproverDashboard />;
}
